namespace TinyTasksKit.Worker.Preferences
{
    public enum PreferenceDataType
    {
        Primitive,
        Collection,
        PathFolder,
    }
}